package com.example.partie1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatToggleButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CheckActivity extends AppCompatActivity {
    TextView t1 , t2;
    EditText  somme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        t1 = findViewById(R.id.textView4);
        t2 = findViewById(R.id.textView5);
        somme = findViewById(R.id.editTextNumber);

        Bundle extras=getIntent().getExtras();
        String n=extras.getString("challenge1");
        String p=extras.getString("challenge2");

        t1.setText(n);
        t2.setText(p);

        Button ok = findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre1 = t1.getText().toString();
                String nombre2 = t2.getText().toString();
                Integer totalResult = Integer.parseInt(nombre1) + Integer.parseInt(nombre2);

                somme.setText("somme = " + Integer.toString(totalResult));


            }
        });








        Button cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentRetour = new Intent(CheckActivity.this, MainActivity.class);
                startActivity(intentRetour);
                Toast.makeText(getApplicationContext(),"opération annulée !", Toast.LENGTH_SHORT).show();

            }
        });

    }
}