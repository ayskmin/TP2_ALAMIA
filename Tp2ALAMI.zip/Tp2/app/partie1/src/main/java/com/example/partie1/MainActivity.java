package com.example.partie1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.partie1.R;

public class MainActivity extends AppCompatActivity {


    private static final int CALL_Perm = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText phoneNumberEditText = findViewById(R.id.editTextPhone2);
        String phoneNumber = phoneNumberEditText.getText().toString();


        ImageButton toSeAc1 = findViewById(R.id.imageButton);
        toSeAc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri phoneUri = Uri.parse("tel:" + phoneNumber);
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(phoneUri);
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CALL_PHONE}, CALL_Perm);
                } else {
                    startActivity(intent);
                }
                startActivity(intent);
            }
        });


        EditText editTextUrl = findViewById(R.id.editTextUrl);
        ImageButton toSeAc2 = findViewById(R.id.imageButton4);
        toSeAc2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondaryActivity.class);
                startActivity(intent);

            }


        });
        EditText challenge1  = findViewById(R.id.textchallenge1);
        EditText challenge2  = findViewById(R.id.textchallenge2);
        ImageButton toSeAc3 = findViewById(R.id.imageButton3);
        toSeAc3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, CheckActivity.class);
                intent.putExtra("challenge1" ,challenge1.getText().toString() );
                intent.putExtra("challenge2" ,challenge2.getText().toString() );
                startActivity(intent);

            }
        });

        challenge1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}